
import SwiftUI

@main
struct TaylorExpressionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
